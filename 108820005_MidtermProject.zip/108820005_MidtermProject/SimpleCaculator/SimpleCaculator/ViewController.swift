//
//  ViewController.swift
//  SimpleCaculator
//
//  Created by kao on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {
    
    let operators = ["+", "-", "*", "/"]
    let operands = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
    var AC = false
    var error = false
    
    @IBOutlet weak var Caculation: UILabel!
    @IBOutlet weak var Answer: UILabel!
    @IBOutlet weak var cleanBtn: UIButton!
    @IBOutlet weak var divisionBtn: UIButton!
    @IBOutlet weak var multiplicationBtn: UIButton!
    @IBOutlet weak var subtractionBtn: UIButton!
    @IBOutlet weak var additionBtn: UIButton!
    
    func removeLast(){
        Caculation.text!.removeLast()
    }
    
    func removerFirst(i:Int){
        Caculation.text!.removeFirst(i)
    }
    
    func forTrailingZero(temp: Double) -> String {
        let tempVar = String(format: "%g", temp)
        return tempVar
    }
    
    func updateCleanButton(){
        if(AC == true){
            cleanBtn.setTitle("AC", for: UIControl.State.normal)
        }
        else{
            cleanBtn.setTitle("C", for: UIControl.State.normal)
        }
        if((String((Caculation.text?.suffix(1))!)) == "+"){
            additionBtn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else if((String((Caculation.text?.suffix(1))!)) == "-"){
            subtractionBtn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else if((String((Caculation.text?.suffix(1))!)) == "*"){
            multiplicationBtn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else if((String((Caculation.text?.suffix(1))!)) == "/"){
            divisionBtn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else{
            additionBtn.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
            subtractionBtn.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
            multiplicationBtn.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
            divisionBtn.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
        }
    }
    
    func checkError(){//檢查是否為/0
        print(String((Caculation.text?.suffix(2))!))
        if(String((Caculation.text?.suffix(2))!) == "/0"){
            error = true
        }
    }
    
    func removeZero(){//去掉非法的0
        var hasDot = false
        var dotPos = 0
        var firstNumPos = 0
        var frontZero = 0
        var endZero = 0
        if(Caculation.text?.length != 0){
            for i in (0..<(Caculation.text!.length+1)).reversed(){
                if (Caculation.text![i] == "."){
                    hasDot = true
                    dotPos = i
                }
                else if(Caculation.text![i] == "+" || Caculation.text![i] == "-" || Caculation.text![i] == "*" || Caculation.text![i] == "/"){
                    firstNumPos = i + 1
                    break
                }
            }
            var x = firstNumPos
            while(Caculation.text![x] == "0"){
                frontZero = frontZero + 1
                x = x + 1
            }
            var y = Caculation.text!.length - 1
            while(Caculation.text![y] == "0"){
                endZero = endZero + 1
                if (y == 0){break}
                y = y - 1
            }
        
            if(hasDot && endZero > 0){
                if(dotPos + endZero == Caculation.text!.length-1){
                    while(endZero>1){
                        removeLast()
                        endZero = endZero-1
                    }
                }
                else{
                    for _ in 1...endZero{
                        removeLast()
                    }
                }
            }
            
            if(hasDot && frontZero > 1){
                if(dotPos == firstNumPos+1){
                    for _ in 1..<frontZero{
                        let index = Caculation.text!.index(Caculation.text!.startIndex, offsetBy: firstNumPos)
                        Caculation.text?.remove(at: index)
                    }
                }
                else{
                    for _ in 1...frontZero{
                        let index = Caculation.text!.index(Caculation.text!.startIndex, offsetBy: firstNumPos)
                        Caculation.text?.remove(at: index)
                    }
                }
            }
            
            if(!hasDot && frontZero > 0){
                for _ in 1...frontZero{
                    let index = Caculation.text!.index(Caculation.text!.startIndex, offsetBy: firstNumPos)
                    Caculation.text?.remove(at: index)
                }
            }
        }
    }
    
    @IBAction func clean(_ sender: UIButton) {
        if(Caculation.text != ""){
            if(!AC){
                if (operands.contains(String((Caculation.text?.suffix(1))!))){
                    removeLast()
                    AC = true
                    if(Caculation.text != ""){
                        while(!operators.contains(String((Caculation.text?.suffix(1))!))){
                            removeLast()
                            if(Caculation.text == ""){
                                AC = false
                                Answer.text = "0"
                                break
                            }
                        }
                    }
                    else{
                        AC = false
                    }
                }
                else{
                    AC = true
                }
            }
            else{
                Caculation.text = ""
                Answer.text = "0"
                sender.setTitle("C", for: UIControl.State.normal)
                AC = false
                error = false
            }
            updateCleanButton()
        }
    }
    
    @IBAction func buttonClick(_ sender: UIButton) {
        Caculation.text = Caculation.text! + sender.currentTitle!
        for case let button as UIButton in self.view.subviews{
            if(button.backgroundColor == #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)){
                button.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
            }
        }
        AC = false
        updateCleanButton()
    }
    
    @IBAction func operatorClick(_ sender: UIButton) {
        removeZero()
        for case let button as UIButton in self.view.subviews{
            if(button.backgroundColor == #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)){
                button.backgroundColor = #colorLiteral(red: 0.9525417686, green: 0.5825939775, blue: 0.2409879565, alpha: 1)
            }
        }
        if(Caculation.text == ""){
            Caculation.text = "0"
            Caculation.text = Caculation.text! + sender.currentTitle!
        }
        else{
            if (!operators.contains(String((Caculation.text?.suffix(1))!))){
                Caculation.text = Caculation.text! + sender.currentTitle!
            }
            else{
                removeLast()
                Caculation.text = Caculation.text! + sender.currentTitle!
            }
        }
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        AC = false
        updateCleanButton()
    }
        
    @IBAction func DotClick(_ sender: UIButton) {
        var setted = false
        if(Caculation.text != ""){
            for index in 1...Caculation.text!.count{
                for i in 0...3{
                    if(String((Caculation.text?.suffix(index))!)).contains(operators[i]){
                        Caculation.text = Caculation.text! + "."
                        setted = true
                        break
                    }
                }
                if(String((Caculation.text?.suffix(index))!)).contains("."){
                    setted = true
                    break
                }
            }
        }
        if(!setted){
            Caculation.text = Caculation.text! + "."
        }
    }
    
    @IBAction func percentage(_ sender: UIButton) {
        Caculation.text =  "(" + Caculation.text! + ")/100"
    }
    
    @IBAction func execute(_ sender: Any) {
        checkError()
        if(!error){
            removeZero()
            let _caculation = Caculation.text!
            let expression = NSExpression(format: _caculation)
            let value = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as?Double
            AC = false
            Answer.text = forTrailingZero(temp: value!) .description
        }
        if(error){
            Answer.text = "0"
            AC = false
        }
        
    }
    
    @IBAction func Reverse(_ sender: Any) {
        if(Caculation.text?.prefix(2) == "-(" && Caculation.text?.suffix(1) == ")"){
            Caculation.text?.removeFirst(2)
            removeLast()
        }
        else{
            Caculation.text =  "-(" + Caculation.text! + ")"
        }
        
    }
    
}

extension String {
    var length: Int {
        return count
    }

    subscript (i: Int) -> String {
        return self[i ..< i + 1]
    }

    func substring(fromIndex: Int) -> String {
        return self[min(fromIndex, length) ..< length]
    }

    func substring(toIndex: Int) -> String {
        return self[0 ..< max(0, toIndex)]
    }

    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return String(self[start ..< end])
    }
}

extension NSExpression {
    func toFloatingPoint() -> NSExpression {
        switch expressionType {
        case .constantValue:
            if let value = constantValue as? NSNumber {
                return NSExpression(forConstantValue: NSNumber(value: value.doubleValue))
            }
        case .function:
           let newArgs = arguments.map { $0.map { $0.toFloatingPoint() } }
           return NSExpression(forFunction: operand, selectorName: function, arguments: newArgs)
        case .conditional:
           return NSExpression(forConditional: predicate, trueExpression: self.true.toFloatingPoint(), falseExpression: self.false.toFloatingPoint())
        case .unionSet:
            return NSExpression(forUnionSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .intersectSet:
            return NSExpression(forIntersectSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .minusSet:
            return NSExpression(forMinusSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .subquery:
            if let subQuery = collection as? NSExpression {
                return NSExpression(forSubquery: subQuery.toFloatingPoint(), usingIteratorVariable: variable, predicate: predicate)
            }
        case .aggregate:
            if let subExpressions = collection as? [NSExpression] {
                return NSExpression(forAggregate: subExpressions.map { $0.toFloatingPoint() })
            }
        case .anyKey:
            fatalError("anyKey not yet implemented")
        case .block:
            fatalError("block not yet implemented")
        case .evaluatedObject, .variable, .keyPath:
            break // Nothing to do here
        @unknown default:
            fatalError("Error")
        }
        return self
    }
}
